# Hello, world!


pairwise.adonis = function(d, v, p.adjust.m = "BH")
{
  require(vegan)
  d = as.matrix(d)
  v = as.character(v)
  pt = adonis(d ~ v)
  if(pt$aov.tab$`Pr(>F)`[1] > 0.05) warning("Overall model not significant!")
  #cat("all versus all : R2 =", pt$aov.tab$R2[1], "; P =", pt$aov.tab$`Pr(>F)`[1], "\n")

  pw = NULL
  P.values = NULL
  R.values = NULL
  for(i1 in 1:(length(unique(v))-1))
  {
    for(i2 in (i1+1):length(unique(v)))
    {
      j = c(which(v == unique(v)[i1]), which(v == unique(v)[i2]))
      pt = adonis(d[j,j] ~ v[j])
      pw = rbind(pw, c(paste(unique(v)[i1], "versus", unique(v)[i2])))
      P.values = c(P.values, pt$aov.tab$`Pr(>F)`[1])
      R.values = c(R.values, pt$aov.tab$R2[1])
    }
  }
  pw = data.frame(pw)
  names(pw) = c("combination")
  pw$R2 = R.values
  pw$P = P.values
  pw$P.adj = p.adjust(P.values,method=p.adjust.m)
  return(pw)
}
